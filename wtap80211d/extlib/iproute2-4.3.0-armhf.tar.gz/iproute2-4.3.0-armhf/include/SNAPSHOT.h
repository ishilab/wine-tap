static const char SNAPSHOT[] = "190924";
